<?php
return [
    'authority'=> 'api.divar.ir',
    'accept'=> 'application/json, text/plain, */*',
    'accept-language'=> 'en-US,en;q=0.9,fa;q=0.8',
    'cache-control'=> 'no-cache',
    'dnt'=> '1',
    'origin'=> 'https=>//divar.ir',
    'pragma'=> 'no-cache',
    'referer'=> 'https=>//divar.ir/',
    'sec-ch-ua'=> '".Not/A)Brand";v="99", "Google Chrome";v="103", "Chromium";v="103"',
    'sec-ch-ua-mobile'=> '?0',
    'sec-ch-ua-platform'=> '"macOS"',
    'sec-fetch-dest'=> 'empty',
    'sec-fetch-mode'=> 'cors',
    'sec-fetch-site'=> 'same-site',
    'user-agent'=> 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
];
