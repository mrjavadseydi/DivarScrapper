<?php
return[
    'همه' => 'ROOT',
    'املاک' => 'real-estate',
    'وسایل نقلیه' => 'vehicles',
    'کالای دیجیتال' => 'electronic-devices',
    'خانه و آشپزخانه' => 'home-kitchen',
    'خدمات' => 'services',
    'وسایل شخصی' => 'personal-goods',
    'سرگرمی و فراغت' => 'entertainment',
    'اجتماعی' => 'social-services',
    'تجهیزات و صنعتی' => 'tools-materials-equipment',
    'استخدام و کاریابی' => 'jobs'
];
